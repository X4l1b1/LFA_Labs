# Lab 03

* Create a Python 3 virtualenv
* `pip install -r requirements.txt`
* `jupyter notebook`
* Follow the instructions in the provided notebook
